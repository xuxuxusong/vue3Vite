<template>
  <A></A>
  <B></B>
  <C></C>
  <D></D>
  <E></E>
  <F></F>
  <G></G>
  <H></H>
  <K></K>
  <L></L>
  <M></M>
  <N></N>
</template>
<script setup lang="ts">
import A from './view/loadComponents/loadA.vue'
import B from './view/loadComponents/loadB.vue'
import C from './view/loadComponents/loadC.vue'
import D from './view/loadComponents/loadD.vue'
import E from './view/loadComponents/loadE.vue'
import F from './view/loadComponents/loadF.vue'
import G from './view/loadComponents/loadG.vue'
import H from './view/loadComponents/loadH.vue'
import K from './view/loadComponents/loadK.vue'
import L from './view/loadComponents/loadL.vue'
import M from './view/loadComponents/loadM.vue'
import N from './view/loadComponents/loadN.vue'
</script>
<style scoped lang="scss">
</style>